# TODO — StockManager

## Navegação e painel inicial
- [x] Criar navegação principal entre as telas Início, Produtos, Movimentações e Relatórios.
  - A navegação deve funcionar no navegador e indicar visualmente a seção ativa.
  - A interface deve ser responsiva e adequada a navegadores modernos.
- [x] Exibir no Início um resumo do estoque.
  - Mostrar total de produtos cadastrados.
  - Mostrar quantidade de itens com baixo estoque.
  - Mostrar valor estimado em estoque e quantidade total de unidades.
  - Listar movimentações recentes com produto, tipo, quantidade e data.

## Produtos
- [x] Implementar listagem e busca de produtos.
  - Permitir pesquisar por nome, código ou categoria.
  - Sinalizar visualmente produtos no limite ou abaixo do estoque mínimo.
  - Exibir nome, código, categoria, quantidade, custo, estoque mínimo e status.
- [x] Implementar cadastro e edição de produtos.
  - Campos obrigatórios: nome, código, categoria, quantidade, preço de custo e estoque mínimo.
  - Validar campos obrigatórios, valores numéricos e código único.
- [x] Implementar exclusão de produtos.
  - Exigir confirmação para evitar remoções acidentais.
  - Remover o produto da listagem sem quebrar o histórico demonstrativo.

## Movimentações
- [x] Implementar registro de entradas.
  - Registrar produto, quantidade, tipo e data.
  - Atualizar automaticamente o saldo disponível.
- [x] Implementar registro de saídas.
  - Registrar produto, quantidade, tipo e data.
  - Impedir quantidades superiores ao estoque disponível.
  - Exibir alerta claro quando a saída for inválida.
- [x] Exibir histórico de movimentações.
  - Mostrar produto, quantidade, tipo e data em ordem recente.

## Relatórios
- [x] Implementar relatório de saldo atual.
  - Apresentar saldo, custo unitário, valor em estoque e participação por categoria.
- [x] Implementar relatório de produtos abaixo do estoque mínimo.
  - Exibir itens críticos e no limite com apresentação clara para acompanhamento operacional.

## Conteúdo e acabamento
- [x] Usar conteúdo demonstrativo realista em português do Brasil.
- [x] Aplicar linguagem visual de dashboard SaaS operacional, com boa hierarquia, contraste, estados de alerta e microinterações.
- [x] Manter o layout funcional em desktop, tablet e mobile.
