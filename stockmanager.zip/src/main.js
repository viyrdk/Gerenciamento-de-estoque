import './styles.css';

const seedProducts = [
  { id: 'p1', name: 'Café Especial 1kg', code: 'CAF-001', category: 'Mercearia', quantity: 24, cost: 31.9, minimum: 10, color: '#5b75e8' },
  { id: 'p2', name: 'Água Mineral 500ml', code: 'BEB-045', category: 'Bebidas', quantity: 8, cost: 2.45, minimum: 12, color: '#16b784' },
  { id: 'p3', name: 'Copos Biodegradáveis', code: 'DES-120', category: 'Descartáveis', quantity: 15, cost: 18.5, minimum: 15, color: '#eead2c' },
  { id: 'p4', name: 'Chocolate 70% Cacau', code: 'DOC-031', category: 'Mercearia', quantity: 41, cost: 8.9, minimum: 12, color: '#f07f62' },
  { id: 'p5', name: 'Papel Toalha Premium', code: 'HIG-076', category: 'Higiene', quantity: 6, cost: 12.75, minimum: 10, color: '#8d7be8' },
  { id: 'p6', name: 'Chá Verde 100g', code: 'BEB-091', category: 'Bebidas', quantity: 28, cost: 14.4, minimum: 8, color: '#388cc8' }
];

const seedMovements = [
  { id: 'm1', productId: 'p1', type: 'entrada', quantity: 12, date: '2026-10-15T08:45:00', note: 'Recebimento fornecedor' },
  { id: 'm2', productId: 'p2', type: 'saida', quantity: 6, date: '2026-10-15T08:12:00', note: 'Venda balcão' },
  { id: 'm3', productId: 'p3', type: 'saida', quantity: 10, date: '2026-10-14T16:30:00', note: 'Uso interno' },
  { id: 'm4', productId: 'p5', type: 'saida', quantity: 4, date: '2026-10-14T14:08:00', note: 'Venda balcão' },
  { id: 'm5', productId: 'p6', type: 'entrada', quantity: 20, date: '2026-10-14T09:22:00', note: 'Reposição programada' },
  { id: 'm6', productId: 'p4', type: 'saida', quantity: 8, date: '2026-10-13T17:14:00', note: 'Venda balcão' }
].map((movement) => ({ ...movement, productName: seedProducts.find((product) => product.id === movement.productId)?.name || 'Produto removido' }));

const storageKey = 'stockmanager-v1';
const restored = loadData();
const state = {
  products: restored?.products?.length ? restored.products : seedProducts,
  movements: restored?.movements?.length ? restored.movements : seedMovements,
  activeView: 'inicio',
  search: '',
  category: 'Todos',
  movementType: 'entrada',
};

const icons = { inicio: '◫', produtos: '▦', movimentacoes: '↕', relatorios: '◔' };
const app = document.querySelector('#app');
const modalRoot = document.querySelector('#modal-root');
const toastRoot = document.querySelector('#toast-root');

function loadData() {
  try { return JSON.parse(localStorage.getItem(storageKey)); } catch { return null; }
}
function saveData() { localStorage.setItem(storageKey, JSON.stringify({ products: state.products, movements: state.movements })); }
function money(value) { return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value); }
function number(value) { return new Intl.NumberFormat('pt-BR').format(value); }
function dateTime(value, compact = false) {
  const parsed = new Date(value);
  const date = new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short' }).format(parsed).replace('.', '');
  const time = new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit' }).format(parsed);
  return compact ? `${date} · ${time}` : `${date}, ${time}`;
}
function todayInput() { return new Date().toISOString().slice(0, 10); }
function productById(id) { return state.products.find((product) => product.id === id); }
function movementProduct(movement) { return productById(movement.productId) || { id: movement.productId, name: movement.productName || 'Produto removido' }; }
function stockStatus(product) {
  if (product.quantity < product.minimum) return { label: 'Crítico', className: 'critical' };
  if (product.quantity === product.minimum) return { label: 'No limite', className: 'attention' };
  return { label: 'Em estoque', className: 'ok' };
}
function lowProducts() { return state.products.filter((product) => product.quantity <= product.minimum).sort((a, b) => (a.quantity / a.minimum) - (b.quantity / b.minimum)); }
function escapeHtml(value = '') { return String(value).replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[character])); }
function initials(name) { return name.split(' ').slice(0, 2).map((part) => part[0]).join('').toUpperCase(); }
function relativeTime(dateString) {
  const minutes = Math.max(1, Math.round((Date.now() - new Date(dateString).getTime()) / 60000));
  if (minutes < 60) return `${minutes} min atrás`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} h atrás`;
  return `${Math.round(hours / 24)} d atrás`;
}

function shell(viewContent) {
  const nav = [
    ['inicio', 'Início'], ['produtos', 'Produtos'], ['movimentacoes', 'Movimentações'], ['relatorios', 'Relatórios']
  ].map(([key, label]) => `<button class="nav-btn ${state.activeView === key ? 'active' : ''}" data-nav="${key}"><span class="nav-icon">${icons[key]}</span><span>${label}</span></button>`).join('');
  const names = { inicio: 'Visão geral', produtos: 'Catálogo de produtos', movimentacoes: 'Fluxo de estoque', relatorios: 'Análise operacional' };
  return `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand"><div class="brand-mark"></div><div class="brand-name">StockManager<small>Gestão de estoque</small></div></div>
        <div class="nav-label">Menu principal</div>
        <nav class="nav-list" aria-label="Navegação principal">${nav}</nav>
        <div class="sidebar-bottom">
          <div class="storage-card"><div class="storage-top"><span>Capacidade do estoque</span><strong>68%</strong></div><div class="meter"><span></span></div></div>
          <div class="profile"><div class="avatar">AM</div><div><div class="profile-name">Ana Martins</div><div class="profile-role">Administradora</div></div></div>
        </div>
      </aside>
      <main class="main">
        <header class="topbar"><div class="breadcrumb"><span>StockManager</span><span class="breadcrumb-sep">/</span><strong>${names[state.activeView]}</strong></div><div class="top-actions"><span class="date-chip">Sincronizado agora</span><button class="icon-button" aria-label="Notificações" title="Notificações"><span>♢</span><i class="notification-dot"></i></button><div class="avatar">AM</div></div></header>
        <div class="content">${viewContent}</div>
      </main>
    </div>`;
}

function pageHeader(eyebrow, title, subtitle, actions = '') {
  return `<div class="page-header"><div><div class="eyebrow">${eyebrow}</div><h1>${title}</h1><p class="page-subtitle">${subtitle}</p></div>${actions ? `<div class="header-actions">${actions}</div>` : ''}</div>`;
}
function kpi(title, value, foot, icon, color) {
  return `<article class="kpi" style="--kpi-bg:${color.bg};--kpi-color:${color.color};--kpi-fade:${color.fade}"><div class="kpi-top"><span>${title}</span><span class="kpi-icon">${icon}</span></div><div class="kpi-value">${value}</div><div class="kpi-foot">${foot}</div></article>`;
}
function movementRow(movement) {
  const product = movementProduct(movement);
  const incoming = movement.type === 'entrada';
  return `<div class="activity-row"><div class="activity-symbol ${incoming ? 'in' : 'out'}">${incoming ? '↓' : '↑'}</div><div class="activity-main"><strong>${escapeHtml(product.name)}</strong><span>${escapeHtml(movement.note || (incoming ? 'Entrada registrada' : 'Saída registrada'))}</span></div><div class="activity-amount ${incoming ? 'in' : 'out'}">${incoming ? '+' : '−'}${number(movement.quantity)}<span class="activity-time">${relativeTime(movement.date)}</span></div></div>`;
}

function dashboard() {
  const low = lowProducts();
  const totalQty = state.products.reduce((sum, product) => sum + product.quantity, 0);
  const totalValue = state.products.reduce((sum, product) => sum + product.quantity * product.cost, 0);
  const productsWithStock = state.products.filter((p) => p.quantity > p.minimum).length;
  const recent = [...state.movements].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5);
  const alerts = low.slice(0, 3).map((product) => `<div class="alert-row ${product.quantity < product.minimum ? 'critical' : ''}"><div class="alert-bar"></div><div class="alert-product"><strong>${escapeHtml(product.name)}</strong><span>Mínimo recomendado: ${number(product.minimum)} un.</span></div><div class="alert-count">${number(product.quantity)} un.</div></div>`).join('');
  return shell(`
    ${pageHeader('Operação de hoje', 'Estoque sob controle.', 'Acompanhe o fluxo de produtos e antecipe reposições.', `<button class="secondary-btn" data-action="go-movements">↕ Registrar movimentação</button><button class="primary-btn" data-action="open-add">＋ Novo produto</button>`)}
    <section class="kpi-grid">
      ${kpi('Produtos cadastrados', number(state.products.length), '<span class="kpi-trend">+2</span> neste mês', '▦', { bg: '#edf0ff', color: '#5b75e8', fade: '#f1f3ff' })}
      ${kpi('Unidades em estoque', number(totalQty), '<span class="kpi-trend">↑ 8,4%</span> vs. semana anterior', '◒', { bg: '#e5f8f1', color: '#0c956c', fade: '#ecfaf5' })}
      ${kpi('Itens para repor', number(low.length), `<span class="kpi-trend alert">${low.length ? 'Atenção necessária' : 'Tudo certo'}</span>`, '!', { bg: '#fff6de', color: '#c68b17', fade: '#fff9ec' })}
      ${kpi('Valor em estoque', money(totalValue), '<span class="kpi-trend">↑ 3,2%</span> valor de custo', 'R$', { bg: '#fff0ed', color: '#e16d52', fade: '#fff5f2' })}
    </section>
    <section class="dashboard-grid">
      <article class="card"><div class="card-head"><div><div class="card-title">Movimentações recentes</div><div class="card-note">Últimas alterações no saldo</div></div><button class="text-link" data-nav="movimentacoes">Ver histórico →</button></div><div class="activity-list">${recent.map(movementRow).join('')}</div></article>
      <article class="card"><div class="card-head"><div><div class="card-title">Saúde do estoque</div><div class="card-note">Panorama dos níveis atuais</div></div><button class="text-link" data-nav="relatorios">Analisar →</button></div><div class="stock-summary"><div class="stock-ring-wrap"><div class="stock-ring"><div>${state.products.length}<small>itens</small></div></div><div class="stock-labels"><div><i class="legend-dot ok"></i>${productsWithStock} em nível ideal</div><div><i class="legend-dot warn"></i>${low.filter((p) => p.quantity === p.minimum).length} no limite</div><div><i class="legend-dot empty"></i>${low.filter((p) => p.quantity < p.minimum).length} abaixo do mínimo</div></div></div><div class="alert-list">${alerts || '<div class="empty-state"><strong>Estoque saudável</strong>Não há itens para repor.</div>'}</div></div></article>
    </section>`);
}

function products() {
  const categories = ['Todos', ...new Set(state.products.map((product) => product.category))];
  const term = state.search.trim().toLowerCase();
  const filtered = state.products.filter((product) => (state.category === 'Todos' || product.category === state.category) && [product.name, product.code, product.category].some((field) => field.toLowerCase().includes(term)));
  const rows = filtered.map((product) => {
    const status = stockStatus(product);
    return `<tr><td><div class="product-cell"><div class="product-avatar" style="background:${product.color}">${initials(product.name)}</div><div><div class="product-name">${escapeHtml(product.name)}</div><div class="product-code">${escapeHtml(product.code)}</div></div></div></td><td>${escapeHtml(product.category)}</td><td><span class="quantity ${product.quantity <= product.minimum ? 'qty-under' : ''}">${number(product.quantity)} un.</span></td><td>${number(product.minimum)} un.</td><td>${money(product.cost)}</td><td><span class="status-pill ${status.className}">${status.label}</span></td><td><div class="row-actions"><button class="mini-btn" aria-label="Editar ${escapeHtml(product.name)}" data-action="edit-product" data-id="${product.id}" title="Editar">✎</button><button class="mini-btn delete" aria-label="Excluir ${escapeHtml(product.name)}" data-action="delete-product" data-id="${product.id}" title="Excluir">×</button></div></td></tr>`;
  }).join('');
  return shell(`
    ${pageHeader('Catálogo', 'Produtos', `${number(state.products.length)} itens monitorados no estoque.`, `<button class="secondary-btn" data-action="export-products">⇩ Exportar</button><button class="primary-btn" data-action="open-add">＋ Cadastrar produto</button>`)}
    <section class="card section-card"><div class="toolbar"><div class="search-wrap"><input class="search" id="product-search" value="${escapeHtml(state.search)}" placeholder="Buscar por nome, código ou categoria" aria-label="Buscar produtos" /></div><select id="category-filter" class="filter-select" aria-label="Filtrar por categoria">${categories.map((category) => `<option ${category === state.category ? 'selected' : ''}>${escapeHtml(category)}</option>`).join('')}</select><span style="margin-left:auto;color:var(--ink-muted);font-size:10px;white-space:nowrap">${number(filtered.length)} resultado${filtered.length === 1 ? '' : 's'}</span></div><div class="table-wrap"><table><thead><tr><th>Produto</th><th>Categoria</th><th>Saldo atual</th><th>Estoque mín.</th><th>Custo un.</th><th>Status</th><th></th></tr></thead><tbody>${rows || `<tr><td colspan="7"><div class="empty-state"><div class="empty-icon">⌕</div><strong>Nenhum produto encontrado</strong>Ajuste a busca ou cadastre um novo item.</div></td></tr>`}</tbody></table></div></section>`);
}

function movements() {
  const recent = [...state.movements].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 12);
  const history = recent.map((movement, index) => {
    const product = movementProduct(movement);
    const incoming = movement.type === 'entrada';
    const day = new Date(movement.date).toDateString();
    const previous = recent[index - 1];
    const newDay = !previous || new Date(previous.date).toDateString() !== day;
    return `${newDay ? `<div class="history-day">${dateTime(movement.date, true).split(' · ')[0]}</div>` : ''}<div class="history-item"><div class="activity-symbol ${incoming ? 'in' : 'out'}">${incoming ? '↓' : '↑'}</div><div><strong>${escapeHtml(product.name)}</strong><span>${escapeHtml(movement.note || 'Movimentação registrada')}</span></div><div class="history-meta" style="color:${incoming ? 'var(--green-deep)' : 'var(--red)'}">${incoming ? '+' : '−'}${number(movement.quantity)} un.<small>${dateTime(movement.date, true).split(' · ')[1]}</small></div></div>`;
  }).join('');
  const options = state.products.map((product) => `<option value="${product.id}">${escapeHtml(product.name)} · ${number(product.quantity)} un.</option>`).join('');
  return shell(`
    ${pageHeader('Controle de fluxo', 'Movimentações', 'Registre entradas e saídas. O saldo é atualizado automaticamente.')}
    <section class="move-layout"><article class="card form-card"><h2>Nova movimentação</h2><p>As saídas são bloqueadas quando ultrapassam o saldo disponível.</p><form id="movement-form" class="form-grid"><div class="type-switch"><button type="button" data-move-type="entrada" class="${state.movementType === 'entrada' ? 'selected in' : ''}">↓ Entrada</button><button type="button" data-move-type="saida" class="${state.movementType === 'saida' ? 'selected out' : ''}">↑ Saída</button></div><div class="field"><label for="movement-product">Produto</label><select id="movement-product" name="productId" required>${options}</select></div><div class="field-row"><div class="field"><label for="movement-quantity">Quantidade</label><input id="movement-quantity" name="quantity" type="number" min="1" placeholder="0" required /></div><div class="field"><label for="movement-date">Data</label><input id="movement-date" name="date" type="date" value="${todayInput()}" required /></div></div><div class="field"><label for="movement-note">Descrição (opcional)</label><input id="movement-note" name="note" maxlength="80" placeholder="Ex.: recebimento fornecedor" /></div><button class="primary-btn submit-wide" type="submit">${state.movementType === 'entrada' ? 'Registrar entrada' : 'Registrar saída'} →</button></form></article><article class="card movement-list"><div class="card-head"><div><div class="card-title">Histórico de movimentações</div><div class="card-note">${number(state.movements.length)} registros no sistema</div></div><button class="text-link" data-action="export-movements">Exportar CSV</button></div><div class="history-list">${history || '<div class="empty-state"><strong>Sem movimentações</strong>Os próximos registros aparecerão aqui.</div>'}</div></article></section>`);
}

function reports() {
  const low = lowProducts();
  const totalValue = state.products.reduce((sum, product) => sum + product.quantity * product.cost, 0);
  const categoryValues = state.products.reduce((acc, product) => { acc[product.category] = (acc[product.category] || 0) + product.quantity * product.cost; return acc; }, {});
  const colors = ['#5b75e8', '#15b784', '#f3bd48', '#fc8b65'];
  const legend = Object.entries(categoryValues).map(([category, value], index) => `<div style="--legend:${colors[index % colors.length]}"><span>${escapeHtml(category)}</span><strong>${Math.round((value / totalValue) * 100)}%</strong></div>`).join('');
  const lowRows = low.map((product) => { const ratio = Math.min(100, Math.round((product.quantity / product.minimum) * 100)); const status = stockStatus(product); return `<tr><td><div class="product-cell"><div class="product-avatar" style="background:${product.color}">${initials(product.name)}</div><div><div class="product-name">${escapeHtml(product.name)}</div><div class="product-code">${escapeHtml(product.category)}</div></div></div></td><td><span class="quantity ${product.quantity < product.minimum ? 'qty-under' : ''}">${number(product.quantity)} un.</span></td><td>${number(product.minimum)} un.</td><td><span class="progress ${status.className}"><span style="width:${ratio}%"></span></span>${ratio}%</td><td><span class="status-pill ${status.className}">${status.label}</span></td></tr>`; }).join('');
  return shell(`
    ${pageHeader('Análise operacional', 'Relatórios', 'Uma visão objetiva para apoiar decisões de reposição.', `<button class="secondary-btn" data-action="export-report">⇩ Baixar relatório</button>`)}
    <section class="kpi-grid"><article class="kpi" style="--kpi-bg:#edf0ff;--kpi-color:#5b75e8;--kpi-fade:#f1f3ff"><div class="kpi-top"><span>Valor total armazenado</span><span class="kpi-icon">R$</span></div><div class="kpi-value">${money(totalValue)}</div><div class="kpi-foot">Custo estimado dos produtos</div></article><article class="kpi" style="--kpi-bg:#e5f8f1;--kpi-color:#0c956c;--kpi-fade:#ecfaf5"><div class="kpi-top"><span>Categorias ativas</span><span class="kpi-icon">◫</span></div><div class="kpi-value">${Object.keys(categoryValues).length}</div><div class="kpi-foot">Distribuição por tipo de produto</div></article><article class="kpi" style="--kpi-bg:#fff6de;--kpi-color:#c68b17;--kpi-fade:#fff9ec"><div class="kpi-top"><span>Reposições prioritárias</span><span class="kpi-icon">!</span></div><div class="kpi-value">${low.length}</div><div class="kpi-foot">Itens no mínimo ou abaixo dele</div></article><article class="kpi" style="--kpi-bg:#fff0ed;--kpi-color:#e16d52;--kpi-fade:#fff5f2"><div class="kpi-top"><span>Últimos movimentos</span><span class="kpi-icon">↕</span></div><div class="kpi-value">${state.movements.length}</div><div class="kpi-foot">Registros de entrada e saída</div></article></section>
    <section class="report-layout"><article class="card report-card"><h2>Valor por categoria</h2><p>Participação no valor total do estoque.</p><div class="donut-area"><div class="donut"><div class="donut-copy"><strong>${money(totalValue)}</strong><span>valor de custo</span></div></div></div><div class="category-legend">${legend}</div></article><article class="card section-card"><div class="card-head"><div><div class="card-title">Produtos que precisam de atenção</div><div class="card-note">Acompanhamento por nível de estoque mínimo</div></div><button class="text-link" data-nav="produtos">Gerenciar produtos →</button></div><div class="table-wrap"><table class="low-table"><thead><tr><th>Produto</th><th>Saldo</th><th>Mínimo</th><th>Nível</th><th>Status</th></tr></thead><tbody>${lowRows || `<tr><td colspan="5"><div class="empty-state"><div class="empty-icon">✓</div><strong>Nenhum alerta no momento</strong>Todos os produtos estão acima do estoque mínimo.</div></td></tr>`}</tbody></table></div></article></section>`);
}

function render() {
  const views = { inicio: dashboard, produtos: products, movimentacoes: movements, relatorios: reports };
  app.innerHTML = views[state.activeView]();
  wireEvents();
}
function wireEvents() {
  document.querySelectorAll('[data-nav]').forEach((button) => button.addEventListener('click', () => { state.activeView = button.dataset.nav; state.search = ''; render(); }));
  document.querySelectorAll('[data-action]').forEach((button) => button.addEventListener('click', () => handleAction(button.dataset.action, button.dataset.id)));
  const search = document.querySelector('#product-search');
  if (search) search.addEventListener('input', (event) => { state.search = event.target.value; render(); setTimeout(() => { const input = document.querySelector('#product-search'); input?.focus(); input?.setSelectionRange(state.search.length, state.search.length); }, 0); });
  const filter = document.querySelector('#category-filter');
  if (filter) filter.addEventListener('change', (event) => { state.category = event.target.value; render(); });
  document.querySelectorAll('[data-move-type]').forEach((button) => button.addEventListener('click', () => { state.movementType = button.dataset.moveType; render(); }));
  const movementForm = document.querySelector('#movement-form');
  if (movementForm) movementForm.addEventListener('submit', submitMovement);
}
function handleAction(action, id) {
  if (action === 'open-add') showProductModal();
  if (action === 'edit-product') showProductModal(productById(id));
  if (action === 'delete-product') showDeleteModal(productById(id));
  if (action === 'go-movements') { state.activeView = 'movimentacoes'; render(); }
  if (action === 'export-products') exportCsv('produtos-stockmanager.csv', [['Produto', 'Código', 'Categoria', 'Quantidade', 'Estoque mínimo', 'Custo unitário'], ...state.products.map((p) => [p.name, p.code, p.category, p.quantity, p.minimum, p.cost])]);
  if (action === 'export-movements') exportCsv('movimentacoes-stockmanager.csv', [['Produto', 'Tipo', 'Quantidade', 'Data', 'Descrição'], ...state.movements.map((m) => { const p = productById(m.productId); return [p?.name || 'Produto removido', m.type, m.quantity, new Date(m.date).toLocaleString('pt-BR'), m.note || '']; })]);
  if (action === 'export-report') exportCsv('relatorio-estoque-stockmanager.csv', [['Produto', 'Categoria', 'Saldo atual', 'Estoque mínimo', 'Custo unitário', 'Valor em estoque'], ...state.products.map((p) => [p.name, p.category, p.quantity, p.minimum, p.cost, (p.quantity * p.cost).toFixed(2)])]);
}
function openModal(content) { modalRoot.innerHTML = `<div class="modal-backdrop" data-modal-close><div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" onclick="event.stopPropagation()">${content}</div></div>`; modalRoot.querySelector('[data-modal-close]').addEventListener('click', closeModal); modalRoot.querySelectorAll('[data-close-modal]').forEach((button) => button.addEventListener('click', closeModal)); }
function closeModal() { modalRoot.innerHTML = ''; }
function showProductModal(product) {
  const editing = Boolean(product);
  const p = product || { name: '', code: '', category: 'Mercearia', quantity: '', cost: '', minimum: '', color: '#5b75e8' };
  openModal(`<div class="modal-head"><h2 id="modal-title">${editing ? 'Editar produto' : 'Cadastrar produto'}</h2><button class="close-btn" data-close-modal aria-label="Fechar">×</button></div><form id="product-form"><div class="modal-body"><div class="form-grid"><div class="field"><label for="prod-name">Nome do produto</label><input id="prod-name" name="name" maxlength="60" value="${escapeHtml(p.name)}" placeholder="Ex.: Café Especial 1kg" required autofocus></div><div class="field-row"><div class="field"><label for="prod-code">Código</label><input id="prod-code" name="code" maxlength="20" value="${escapeHtml(p.code)}" placeholder="EX: CAF-001" required></div><div class="field"><label for="prod-category">Categoria</label><input id="prod-category" name="category" maxlength="35" value="${escapeHtml(p.category)}" placeholder="Ex.: Mercearia" required></div></div><div class="field-row"><div class="field"><label for="prod-quantity">Quantidade inicial</label><input id="prod-quantity" name="quantity" type="number" min="0" step="1" value="${p.quantity}" required></div><div class="field"><label for="prod-minimum">Estoque mínimo</label><input id="prod-minimum" name="minimum" type="number" min="0" step="1" value="${p.minimum}" required></div></div><div class="field"><label for="prod-cost">Preço de custo (R$)</label><input id="prod-cost" name="cost" type="number" min="0" step="0.01" value="${p.cost}" placeholder="0,00" required></div></div></div><div class="modal-actions"><button type="button" class="secondary-btn" data-close-modal>Cancelar</button><button type="submit" class="primary-btn">${editing ? 'Salvar alterações' : 'Cadastrar produto'}</button></div></form>`);
  modalRoot.querySelector('#product-form').addEventListener('submit', (event) => submitProduct(event, product?.id));
}
function submitProduct(event, productId) {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget));
  const duplicate = state.products.find((p) => p.code.toLowerCase() === data.code.trim().toLowerCase() && p.id !== productId);
  if (duplicate) return showToast('Código já utilizado', 'Cada produto deve ter um código único.', true);
  const details = { name: data.name.trim(), code: data.code.trim().toUpperCase(), category: data.category.trim(), quantity: Number(data.quantity), minimum: Number(data.minimum), cost: Number(data.cost) };
  if (!details.name || !details.code || !details.category || [details.quantity, details.minimum, details.cost].some((value) => Number.isNaN(value) || value < 0)) return showToast('Confira os campos', 'Preencha os dados obrigatórios com valores válidos.', true);
  if (productId) { const product = productById(productId); Object.assign(product, details); showToast('Produto atualizado', `${details.name} foi alterado com sucesso.`); } else { state.products.unshift({ id: `p${Date.now()}`, color: ['#5b75e8','#16b784','#eead2c','#f07f62','#8d7be8','#388cc8'][state.products.length % 6], ...details }); showToast('Produto cadastrado', `${details.name} já está disponível no estoque.`); }
  saveData(); closeModal(); render();
}
function showDeleteModal(product) {
  if (!product) return;
  openModal(`<div class="modal-head"><h2 id="modal-title">Excluir produto?</h2><button class="close-btn" data-close-modal aria-label="Fechar">×</button></div><div class="modal-body"><p>Deseja mesmo excluir <strong>${escapeHtml(product.name)}</strong>? O produto será removido do catálogo. O histórico anterior será preservado como registro.</p></div><div class="modal-actions"><button class="secondary-btn" data-close-modal>Cancelar</button><button class="danger-btn" id="confirm-delete">Excluir produto</button></div>`);
  modalRoot.querySelector('#confirm-delete').addEventListener('click', () => { state.products = state.products.filter((item) => item.id !== product.id); saveData(); closeModal(); render(); showToast('Produto excluído', `${product.name} foi removido do catálogo.`); });
}
function submitMovement(event) {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget));
  const product = productById(data.productId);
  const quantity = Number(data.quantity);
  if (!product || !Number.isInteger(quantity) || quantity <= 0) return showToast('Quantidade inválida', 'Informe uma quantidade inteira maior que zero.', true);
  if (state.movementType === 'saida' && quantity > product.quantity) return showToast('Saída bloqueada', `${product.name} possui apenas ${number(product.quantity)} unidade(s) disponível(is).`, true);
  product.quantity += state.movementType === 'entrada' ? quantity : -quantity;
  state.movements.unshift({ id: `m${Date.now()}`, productId: product.id, productName: product.name, type: state.movementType, quantity, date: `${data.date}T${new Date().toTimeString().slice(0, 8)}`, note: data.note.trim() || (state.movementType === 'entrada' ? 'Entrada registrada' : 'Saída registrada') });
  saveData(); render(); showToast(state.movementType === 'entrada' ? 'Entrada registrada' : 'Saída registrada', `${number(quantity)} unidade(s) de ${product.name} foram ${state.movementType === 'entrada' ? 'adicionadas' : 'retiradas'}.`);
}
function exportCsv(fileName, rows) {
  const csv = rows.map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(';')).join('\n');
  const url = URL.createObjectURL(new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8;' }));
  const link = Object.assign(document.createElement('a'), { href: url, download: fileName }); link.click(); URL.revokeObjectURL(url); showToast('Arquivo preparado', 'O download do CSV foi iniciado.');
}
function showToast(title, message, error = false) { const toast = document.createElement('div'); toast.className = `toast${error ? ' error' : ''}`; toast.innerHTML = `<div class="toast-icon">${error ? '!' : '✓'}</div><div><strong>${escapeHtml(title)}</strong><span>${escapeHtml(message)}</span></div>`; toastRoot.append(toast); setTimeout(() => toast.remove(), 4100); }

render();
